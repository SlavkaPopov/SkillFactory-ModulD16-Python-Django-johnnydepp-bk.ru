from django.contrib import admin
from .models import Author, Category, Post, PostCategory, Comment


# создаём новый класс для представления товаров в админке
class AuthorAdmin(admin.ModelAdmin):
    # list_display — это список или кортеж со всеми полями, которые вы хотите видеть в таблице с товарами
    list_display = [field.name for field in Author._meta.get_fields()]  # генерируем список имён всех полей для более красивого отображения
    list_filter = ('name_author', )  # добавляем примитивные фильтры в нашу админку
    search_fields = ('rating', )  # тут всё очень похоже на фильтры из запросов в базу


# создаём новый класс для представления товаров в админке
class CategoryAdmin(admin.ModelAdmin):
    # list_display — это список или кортеж со всеми полями, которые вы хотите видеть в таблице с товарами
    list_display = [field.name for field in Category._meta.get_fields()]  # генерируем список имён всех полей для более красивого отображения
    list_filter = ('name_category', )  # добавляем примитивные фильтры в нашу админку
    search_fields = ('subscribers', )  # тут всё очень похоже на фильтры из запросов в базу


# создаём новый класс для представления товаров в админке
class PostAdmin(admin.ModelAdmin):
    # list_display — это список или кортеж со всеми полями, которые вы хотите видеть в таблице с товарами
    list_display = [field.name for field in Post._meta.get_fields()]  # генерируем список имён всех полей для более красивого отображения
    list_filter = ('id_authors', 'title', 'post_category__name_category')  # добавляем примитивные фильтры в нашу админку
    search_fields = ('time_in', )  # тут всё очень похоже на фильтры из запросов в базу


# Register your models here.
admin.site.register(Author)
admin.site.register(Category)
admin.site.register(Post)
admin.site.register(PostCategory)
admin.site.register(Comment)
